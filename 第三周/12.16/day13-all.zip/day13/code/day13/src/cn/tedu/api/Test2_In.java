package cn.tedu.api;
import java.io.*;

//测试 读取流:把磁盘里的数据 读到程序中
//1,FileInputStream 普通流,一个字节一个字节读,慢
//2,BufferedInputStream 缓冲流/高级流,一个数组一个数组的读,快

//效率:BufferedInputStream > FileInputStream
//原因是:BufferedInputStream底层维护一个缓冲数组
//byte[] buf,默认容量8192个字节.8K的容量.
//一次性把数组里的数据批量读到程序中,提高了单字节的读取效率
public class Test2_In {
    public static void main(String[] args) throws IOException {
//        method();//FileInputStream读取流读取流
        method2();//BufferedInputStream读取流
    }
    //BufferedInputStream读取流
    private static void method2() throws IOException {
        //1,创建多态对象测试
//      BufferedInputStream(InputStream in)
        InputStream in =
            new BufferedInputStream (
                new FileInputStream("D:\\iotest\\1.txt")
            );
        //2,开始读取
        int b = 0 ;//定义变量,记录读到的数据
        //一个一个的读,直到没数据了,返回-1就结束啦
        while( ( b = in.read() ) != -1){
            //打印读到的数据
            System.out.println(b);
        }
        //3,释放资源
        in.close();
    }
    //普通读取流
    public static void method() throws IOException {
    //1,创建多态对象--创建子类对象时,只提供了含参构造
//FileInputStream(File file)
//InputStream in = new FileInputStream( new File("D:\\iotest\\1.txt"));

//FileInputStream(String name)--name是文件路径
        InputStream in =
           new FileInputStream("D:\\iotest\\1.txt");
        //2,开始读取
        //多态对象,只能调用父类的功能,统一调用的标准
//        int data = in.read();//一个一个的读取
//        System.out.println(data);
//        int data2 = in.read();
//        System.out.println(data2);
//        int data3 = in.read();
//        System.out.println(data3);

//     没数据了,再读,会读到什么?? -- 永远得到-1
//        int data4 = in.read();
//        System.out.println(data4);
//        int data5 = in.read();
//        System.out.println(data5);
//        int data6 = in.read();
//        System.out.println(data6);
        // TODO 改造读取
        //循环结构 重复读,读到-1就停
        int b = 0;//定义变量,记录读到的数据
        //read()就是一个一个读,读到-1就是没数据了,就停
        while ( ( b = in.read() ) != -1){
            System.out.println(b);
        }
        //3,释放资源
        in.close();
//TODO 释放资源后,还能读吗??--不能,Stream Closed
//        int data7 = in.read();
//        System.out.println(data7);
    }
}
