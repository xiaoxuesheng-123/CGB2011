package cn.tedu.api;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

//测试 写出流:
public class Test3_Out {
    public static void main(String[] args)
            throws IOException {
        method();//FileOutputStream写出
//        method2();//BufferedOutputStream高效写出流
    }
    //普通流写出
    public static void method() throws IOException {
        //1,创建多态对象测试
        //FileOutputStream(String name)--数据覆盖
//        OutputStream out =new FileOutputStream("D:\\iotest\\1.txt");

 //FileOutputStream(String name, boolean append)
 //第二个参数如果是true,就是数据追加模式
 OutputStream out =new FileOutputStream(
         "D:\\iotest\\1.txt",true);
        //2,开始写出
        out.write(98);
        out.write(99);
        out.write(97);
        out.write(97);
        //3,释放资源
        out.close();


    }
}
