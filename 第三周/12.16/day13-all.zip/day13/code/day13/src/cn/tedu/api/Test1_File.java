package cn.tedu.api;

import java.io.File;
import java.util.Scanner;

//测试 File工具类
public class Test1_File {
    public static void main(String[] args) {
//       method(); //统计 文件夹里 文件的总大小
       System.out.println("请输入 文件夹路径:");
       String dirpath = new Scanner(System.in).nextLine();
       //封装文件夹路径
       File dir = new File(dirpath);
       long total = method2(dir); //求目录的总大小
        System.out.println(total);
    }
    //求目录的总大小
    private static long method2(File wjj) {
        File[] fs = wjj.listFiles();//列出资源
        //遍历数组,获取每个资源fs[i]
        long sum = 0;//定义变量,记录和
        for (int i = 0; i < fs.length; i++) {
    //      判断,是文件就直接length()求和
            if(fs[i].isFile()){
                sum = sum + fs[i].length();//求和
            }else if(fs[i].isDirectory()){
             //递归--在方法内部调用自己--因为发生了和自己一样的过程
             // 因为是文件夹的话就开始重复执行method2()的过程了
                sum = sum + method2(fs[i]);
            }
        }
        return sum ;//总和返回调用位置
    }
    //TODO 统计 文件夹里 文件的总大小
    public static void method() {
        //把指定的路径 封装成File对象,用方法
 File file = new File("D:\\iotest");
        //列资源
        File[] fs = file.listFiles();
        //遍历数组
        long sum  = 0 ;//定义变量,记录总和
        for (int i = 0; i < fs.length; i++) {
           //获取每个资源f
            File f = fs[i];
            //判断,资源是文件就求和
            if(f.isFile()){
                sum = sum + f.length();//求和
            }
        }
        System.out.println("文件的总大小是: "+sum);
    }

}
