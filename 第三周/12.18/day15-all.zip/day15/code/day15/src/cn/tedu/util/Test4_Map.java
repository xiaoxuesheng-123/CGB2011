package cn.tedu.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

//测试 Map接口
public class Test4_Map {
    public static void main(String[] args) {
        //1,创建 多态对象
        Map<Integer,String> map = new HashMap();
        //2,调用方法
        map.put(9527,"唐伯虎");
//TODO 必须添加键值对的数据.可以同时约束,k和v的数据类型
        map.put(9528,"秋香姐");
        map.put(9529,"石榴姐");
        //TODO 当key相同时,原来的value会被覆盖
        map.put(9528,"秋香姐2");
 //TODO {9527=唐伯虎, 9528=秋香姐2, 9529=石榴姐}
        System.out.println(map);
        //根据key获取value
        System.out.println(map.get(9527));
//        map.clear();//清空集合
        //判断是否包含指定的key
        System.out.println(map.containsKey(9528));
        //判断是否包含指定的value
        System.out.println(map.containsValue(100));
        //判断是否相等
        System.out.println(map.equals(999));
        //获取哈希码值
        System.out.println(map.hashCode());
        //判断是否为空map
        System.out.println(map.isEmpty());
        //获取map长度
        System.out.println(map.size());
        //根据key移除记录,并返回value的值null
        System.out.println(map.remove(9529));
        //TODO 迭代map集合
//TODO 方式1:Set<K> keySet()-把map里的key们存入set
        Set<Integer> keys = map.keySet();
        //迭代set,获取每个key
        for (Integer  key : keys){
            //拿着key回map里找value
            String value = map.get(key);
            if(value.equals("秋香姐2")){
                System.out.println(value+",加个微信呗~");
            }
            System.out.println(key + value);
        }
//TODO 方式2:Collection<V> values()--把map里的value们存入Collection
        //调用values(),遍历Collection获取每个value

//TODO 方式3:Set<Map.Entry<K,V>> entrySet()
//          --把map里的key和value一起存入set
        //调用entrySet(),迭代set获取每个Entry,
        //调用Entry提供的方法获取key和value

    }
}
