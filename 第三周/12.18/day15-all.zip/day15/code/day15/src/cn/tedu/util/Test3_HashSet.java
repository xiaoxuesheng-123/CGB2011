package cn.tedu.util;

import java.util.HashSet;
import java.util.Iterator;

//测试 Set接口
public class Test3_HashSet {
    public static void main(String[] args) {
        //1,创建 多态 对象
 //TODO 当创建HashSet对象时,本质上是创建了一个HashMap对象
        HashSet<String> set = new HashSet();
        //2,调用方法
        //TODO 全是继承自Collection接口的方法
        set.add("tony");
 //TODO 当往set里加数据时,本质上是往map里加了
        set.add("jerry");
        set.add("tom");
        set.add("rose");
        set.add("tony");
        set.add("tom");
        set.add("rose");
        set.add(null);
        set.add(null);
        //特点:不重复!! + 无序 + 一个null + 没下标
        System.out.println(set);
        //TODO 迭代set集合
        //方式1: Iterator<E> iterator()
        Iterator<String> it = set.iterator();
        while (it.hasNext()){
            String s = it.next();
            System.out.println(s);
        }
        //方式2: 增强for
        for(String s : set){
            System.out.println(s);
        }
    }
}
