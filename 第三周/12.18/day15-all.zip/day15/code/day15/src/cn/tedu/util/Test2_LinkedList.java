package cn.tedu.util;

import java.util.LinkedList;

//测试 LinkedList
public class Test2_LinkedList {
    public static void main(String[] args) {
        //1,创建对象
        //空的链表
        LinkedList<String> list = new LinkedList();
        //2,调用方法
        //TODO 继承自上层接口的
 //底层是一个链表结构,每个链表上的元素叫Node
 //Node间维护的关系,是靠prev绑定前面一个元素的关系
 //next绑定后面一个元素的关系
        list.add("蜘蛛侠");
        list.add("猪猪侠");
        list.add("皮皮霞");
        list.add("猪猪侠");
        list.add(null);
        //自己扩展的--操作首尾元素
        list.addFirst("灭霸");//添加首元素
        list.addLast("美队");//添加尾元素
        System.out.println(list);
        System.out.println(list.getFirst());//获取首元素
        System.out.println(list.getLast());//获取尾元素
        System.out.println(list.removeFirst());//移除首元素
        System.out.println(list.removeLast());//移除尾元素
        //TODO--操作首尾元素 第二套API
//        boolean offerFirst(E e)
//        boolean offerLast(E e)
//        E peekFirst()
//        E peekLast()
//        E pollFirst()
//        E pollLast()

    }
}
