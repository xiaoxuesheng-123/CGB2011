package cn.tedu.util;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.ListIterator;

//测试 ArrayList
public class Test1_ArrayList {
    public static void main(String[] args) {
        //1,创建对象
 //TODO 原理:
// jdk1.6是一旦创建ArrayList对象就分配10个容量的Object[] elementData
 //jdk1.8 是当第一次添加元素时,才分配10个容量的Object[] elementData
 // 当调用add()时,拿着数据,存到了数组里,方便以后的查询,
  // 而且保证了存储顺序
        ArrayList list = new ArrayList();
        //2,调用方法
        //有序 + 可重复 + 存null
        list.add(100);
        list.add(0,200);
        list.add(null);
        list.add(100);
        list.add(null);
        System.out.println(list);
        //有下标
        //TODO 迭代list集合的4种方式
        Iterator it = list.iterator();
        while (it.hasNext()){
            //取元素 + 后移指针
            Object o = it.next();
            System.out.println(o);
        }
        ListIterator it2 = list.listIterator();
        while(it2.hasNext()){
            Object o = it2.next();
            System.out.println(o);
        }
        for (int i = 0; i < list.size() ; i++) {
            Object o = list.get(i);
            System.out.println(o);
        }
        for (Object o : list) {
            System.out.println(o);
        }

        //练习:模拟ArrayList存数据
   //TODO 1,数组存数据,为了存的类型丰富,
   // 最好是Object类型,默认容量是10,不够自动扩容
       int size = 0;
       Object[] a = new Object[10];
       a[size++] = 10;
       a[size++] = 1.1;
       a[size++] = "hello";
       a[size++] = true;
   //TODO 2,容量不够就扩容
       if(size > a.length){
   //TODO 3,底层扩容方式:是原数组的1.5倍
           Object[] b = Arrays.copyOf(a, (int)(a.length*1.5));
           System.out.println(b);
       }
    }
}
