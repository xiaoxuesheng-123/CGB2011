package cn.tedu.io;

import java.io.*;
import java.util.Scanner;

//测试 文件复制
public class Test1_Copy {
    public static void main(String[] args) throws IOException {
        System.out.println("请输入 源文件 的路径:");
        String frompath= new Scanner(System.in).nextLine();

        System.out.println("请输入 目标文件 的路径:");
        String topath= new Scanner(System.in).nextLine();
        //调用方法,完成复制
        copyFile(frompath,topath);
        System.out.println("文件复制已完成!");
    }
    //完成文件复制
    private static void copyFile(
            String frompath, String topath) throws IOException {
        //读取源文件frompath,写出到目标文件topath里去
        //1,准备 读写流
        InputStream in = new BufferedInputStream(
                new FileInputStream(frompath) );
        OutputStream out = new BufferedOutputStream(
                new FileOutputStream(topath) );
        //2,开始读写
        int b = 0;//定义变量,记录读到的数据
        while( ( b = in.read() ) != -1){
            out.write(b);//写出
        }
        //3,关闭资源
        in.close();
        //把out流 里的数据,刷到磁盘里
//        out.flush();//刷新
        out.close();//flush + close

        //面试题:flush 和 close的区别

    }
}
