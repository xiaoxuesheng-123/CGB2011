package cn.tedu.util;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;

//测试 Collection接口的方法们
public class Test3_Collection {
    public static void main(String[] args) {
        //1,创建多态对象测试
        Collection c = new ArrayList();
        //2,调用方法
        c.add(1);//添加元素
        c.add(2);
        c.add(3);
        System.out.println(c);//[1, 2, 3]
        System.out.println(c.contains(2));//是否包含
        System.out.println(c.equals(123));//是否相等
        System.out.println(c.hashCode());//c哈希码值
        System.out.println(c.isEmpty());//是否为空
        System.out.println(c.remove(3));//移除3这个元素
        System.out.println(c.size());//集合的长度
        System.out.println(c);//[1, 2]
//        c.clear();//清空c集合
//        System.out.println(c.size());//0
        //把c里的元素,存入数组里
        Object[] os = c.toArray();
        //[1, 2]
        System.out.println(Arrays.toString(os));
        //TODO 集合间的操作--了解
        Collection c2 = new ArrayList();
        c2.add(2);
        c2.add(3);
        System.out.println(c.addAll(c2));//把c2加入c
        System.out.println(c.containsAll(c2));//c里有c2吗
        System.out.println(c.removeAll(c2));//移除交集
        System.out.println(c.retainAll(c2));//保留交集

        //TODO 迭代集合--一个一个获取集合里的元素
//Iterator<E> iterator():Iterator是一个接口,用来迭代集合
        Iterator it = c.iterator();
        //hasNext() 判断有没有元素
        while(it.hasNext()){
            Object o = it.next();//next()获取元素
            System.out.println(o);
        }

    }
}
