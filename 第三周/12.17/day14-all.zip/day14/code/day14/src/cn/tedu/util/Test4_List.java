package cn.tedu.util;

import javax.sound.sampled.SourceDataLine;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

//测试 List接口的方法
public class Test4_List {
    public static void main(String[] args) {
        //1,创建多态对象测试
    //TODO 泛型用来约束集合里的元素类型,只能写引用类型
        List<Integer> list = new ArrayList();
        //2,调用方法
//        继承自父接口的 略...
        list.add(100);
        list.add(200);
        list.add(300);
        list.add(100);
        list.add(null);
        list.add(200);
        list.add(null);
        //特点:有序+可重复+可以存多个null+有索引
        System.out.println(list);
 //[100, 200, 300, 100, null, 200, null]
        //自己扩展的--根据索引操作数据
        list.add(2,500);//在下标2处插入500元素
        System.out.println(list.get(3));//根据下标获取元素
        //获取元素100,第一次出现的索引值
        System.out.println(list.indexOf(100));
        //获取元素100,最后一次出现的索引值
        System.out.println(list.lastIndexOf(100));
        //移除下标为3的元素
        System.out.println(list.remove(3));
        //把下标为4的元素,替换成666
        System.out.println(list.set(4,666));
        //截取子List,含头不含尾 [1,5)
        List<Integer> list2 = list.subList(1, 5);
//        boolean addAll(int index, Collection c)

        //TODO 迭代List集合
        //方式1:继承来的Iterator<E> iterator()
        Iterator<Integer> it = list.iterator();
        while (it.hasNext()){//判断有没有元素
            Integer data = it.next();//获取元素
            System.out.println(data);//打印元素
        }
        //方式2:自己扩展的ListIterator<E> listIterator()
        ListIterator<Integer> it2 = list.listIterator();
        //正向迭代
        while(it2.hasNext()){//判断后面有元素吗
            Integer data = it2.next();//获取后面的元素
            System.out.println(data);
        }
        //逆向迭代--了解--必须先正向迭代
        while(it2.hasPrevious()){//判断前面有元素吗
            Integer data = it2.previous();//获取前面的元素
            System.out.println(data);
        }
//TODO 面试题:方式1 和 方式2的区别??
//方式1返回的接口是父接口,方式2返回的接口是子接口
//父接口里只提供了正向迭代的方法,子接口除了正向迭代 ,还扩展了 逆向迭代--不用!!
        //方式3:根据下标迭代
        for (int i = 0; i < list.size(); i++) {
            //根据下标获取元素
            Integer data = list.get(i);
            System.out.println(data);
        }
        //方式4:增强for循环/foreach循环
        //语法:for(得到的数据的类型  变量名 : 循环的容器){}
        //使用场景:数组 | Collection集合
        //缺点:没法根据下标操作具体元素
        for(Integer  a : list){
            System.out.println(a);
        }

        int[] a = {1,2,3,4,5};
// for(int i = 0;i < a.length;i++){System.out.println(a[i]);}
// for(int data : a){System.out.println(data);}


    }
}
