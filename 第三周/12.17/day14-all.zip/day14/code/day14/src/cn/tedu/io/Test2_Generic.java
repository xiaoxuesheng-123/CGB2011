package cn.tedu.io;

import java.util.ArrayList;
import java.util.List;

//测试 泛型的作用
public class Test2_Generic {
    public static void main(String[] args) {
//        method();//类型检查
        method2();//增强通用性
    }
    //打印数组里的数据
    private static void method2() {
        Integer[] a = {1,2,3,4,5};
        print(a);
        Double[] b = {1.1,2.2,3.3,4.4,5.5};
        print(b);
        String[] c = {"杨幂","Anglelababa","古力娜扎","迪丽热巴"};
        print(c);
    }
    //作用2:泛型的通用性
    //在方法上用泛型,两个位置必须同时出现..
    private static <E> void print(E[] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.println(a[i]);
        }
    }
    //作用1:类型检查 + 报错前置
    private static void method() {
        //模拟数组:类型检查+报错前置
//        int[] a = {1.1,2,3,4,5};
        //1,集合里可以添加 任意类型 的元素
        List list = new ArrayList();
        list.add(10);
        list.add(2.3);
        list.add(true);
        list.add("hello");
        //2,使用泛型 约束list2集合里元素的类型String
        List<String> list2 = new ArrayList();
        list2.add("100");
        list2.add("200");
//      list2.add(100);//没有通过泛型的类型检查

        //3,泛型的<??>--??不能是基本类型,必须是引用类型
        List<Integer> list3 = new ArrayList();
        //1是基本类型,约束的必须是包装类型,为什么不报错?
        list3.add(1);
        //自动装箱-把基本类型变成包装类型 new Integer(1)

    }
}
