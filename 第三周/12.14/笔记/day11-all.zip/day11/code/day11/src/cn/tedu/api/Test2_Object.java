package cn.tedu.api;
import java.util.Objects;
//测试 重写 Object里的方法
//总结
//1,重写toString():
    //默认使用了父类Object的,就是展示地址值.想展示属性值
//2,重写equals():
    //默认使用了父类Object的,就是==比较地址值,想比较属性值
//3,IDEA自动生成代码:右键-generate....
//Eclipse自动生成代码:右键-source-generate........
public class Test2_Object {
    public static void main(String[] args) {
        //创建Student对象
        Student s = new Student("tony",100);
        String s1 = s.toString();
        //1,默认就是使用了父类Object的toString(),
//重写toString()前,展示地址值cn.tedu.api.Student@1b6d3586
//重写toString()后,展示属性值Student{name='tony', age=100}
        System.out.println(s1);

        Student s2 = new Student("蔡徐坤",18);
        Student s3 = new Student("蔡徐坤",18);
        boolean b = s2.equals(s3) ;
        //3,equals():比较两个对象是否相等
        //默认用了父类Object提供的,使用==比较
        //==比较基本类型的 值本身,比较引用类型的 地址值
        //重写equals()前,比的是地址值
        //重写equals()后,比较属性值
        System.out.println(b);
    }
}
class Student extends Object{
//4,重写equals()::默认比较的是地址值,想比属性值
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        //把参数obj转型,转成Student类型
        Student student = (Student) o;
        //拿着属性比较,如果属性都一样,就让equals()返回true
        return age == student.age &&
                Objects.equals(name, student.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, age);
    }

    //2,重写的toString()::不想展示地址值，想展示属性值
//generate-toString()-ok
    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    //TODO Constructors..
    public Student(){}
    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }
    //TODO fields
    private String name;
    private int age;
    //TODO get/set--右键-generate-getter and setter-ok
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
}

