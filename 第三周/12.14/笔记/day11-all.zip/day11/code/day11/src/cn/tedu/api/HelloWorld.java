package cn.tedu.api;

//测试 入门案例
public class HelloWorld {
    //main psvm
    public static void main(String[] args) {
        //sout
        System.out.println(123);
        //复制一行 ctrl d
        //删除一行 ctrl x
        System.out.println(123);
        System.out.println(123);
        System.out.println(123);
        System.out.println(123);
        //调整位置 ctrl shift 箭头
        //格式化代码  ctrl alt l
        //注释 ctrl  /
        //for循环  fori
//        for (int i = 0; i < 10 ; i++) {}

    }
}
