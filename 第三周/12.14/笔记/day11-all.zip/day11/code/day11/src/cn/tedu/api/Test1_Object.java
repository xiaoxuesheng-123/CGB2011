package cn.tedu.api;
//测试 Object工具类
public class Test1_Object {
    public static void main(String[] args) {
        //1,创建对象
        Object o = new Object();
        //底层会自动调用o.toString()
        // java.lang.Object@1b6d3586
        System.out.println(o);
        //2,调用方法
        String s = o.toString();
        //返回o对象在内存中的地址值
        //java.lang.Object@1b6d3586
        System.out.println(s);

        int i = o.hashCode();
        //o对象在内存中的哈希码值
        System.out.println(i);//460141958

 //参数Object体现了灵活性,通用性--多态
//        boolean equals(Object obj)
        boolean b = o.equals("123");
        //比较o和"123"是否相等
        System.out.println(b);//false
    }
}
