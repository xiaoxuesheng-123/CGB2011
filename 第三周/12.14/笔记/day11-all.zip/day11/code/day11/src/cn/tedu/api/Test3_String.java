package cn.tedu.api;
//测试 字符串
public class Test3_String {
    public static void main(String[] args) {
        //1,创建String对象
        String s = new String();
        //TODO 特点:String底层是一个char[]
//      String(char[] value)
        char[] value = {'h','e','l','l','o'};
        String s2 = new String(value);
        //2,调用方法
        System.out.println( s2.charAt(2) );//获取下标2对应的字符
        System.out.println( s2.concat("123") );//在s2后面拼接"123"
        System.out.println( s2.contains("xyz") );//判断s2包含"xyz"吗
        System.out.println( s2.endsWith("llo") );//判断s2是否以"llo"结尾
        System.out.println( s2.equals("hello") );//判断s2是否与?相等

        //TODO 测试其他方法
//        int hashCode()
//        int indexOf(String str)
//        boolean isEmpty()
//        int lastIndexOf(String str)
//        int length()
//        String replace(char oldChar, char newChar)
//        boolean startsWith(String prefix)
//        String substring(int beginIndex)
//        String substring(int beginIndex, int endIndex)
//        String toLowerCase()
//        String toString()
//        String toUpperCase()
//        String trim()

//        static String valueOf(int i)
//        char[] toCharArray()
//        String[] split(String regex)
//        byte[] getBytes()

    }
}
