package cn.tedu.api;
//测试 字符串 拼接的 工具类
//1,专门用来 优化 大量 的字符串拼接的需求
//2,创建工具类对象+调用append()追加数据
public class Test1 {
    public static void main(String[] args) {
//        method();//用+拼接
        method2();//用工具拼接
    }
    //用工具拼接
    public static void method2() {
        String s = "abcdefghijklmn";
        //1,创建对象
        StringBuilder sb = new StringBuilder();
        long start = System.currentTimeMillis();//计时开始
        for (int i = 0; i < 10000; i++) {
            //2,调用拼接方法
            sb.append(s);
        }
        long end = System.currentTimeMillis(); //计时结束
        System.out.println(end-start);//1ms
    }
    //用+拼接
    public static void method() {
        String s = "abcdefghijklmn";
        //把s拼接10000次,并打印结果
        String s2 ="";//定义变量,记录结果
long start = System.currentTimeMillis();//计时开始
        for (int i = 0; i < 10000; i++) {
            s2 = s2+s ;
        }
long end = System.currentTimeMillis(); //计时结束
        System.out.println(end-start);//1132ms
    }
}
