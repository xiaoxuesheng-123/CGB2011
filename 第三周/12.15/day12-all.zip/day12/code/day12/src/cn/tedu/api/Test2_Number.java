package cn.tedu.api;
//测试 包装类
public class Test2_Number {
    public static void main(String[] args) {
        //1,创建Integer对象 -- 自动装箱
  //把5从基本类型 变成 Integer类型,用Integer的各种方法
        Integer in = new Integer(5);
        Integer in2 = Integer.valueOf(5);

        //TODO 2,调用方法
//      把包装类 变成 基本类型 -- 自动拆箱-参与运算
        int a = in.intValue();
        System.out.println(a);//5

//      把字符串类型的整数  解析成int类型
        int x = Integer.parseInt("100");
        System.out.println(x);

        //double -> Double:使用Double的方法--自动装箱
        Double d = new Double(3.2);
        Double d2 = Double.valueOf(3.2);
        //Double -> double:参与运算--自动拆箱
        double d3 = d.doubleValue();
        System.out.println(d3+1);//4.2
    }
}
