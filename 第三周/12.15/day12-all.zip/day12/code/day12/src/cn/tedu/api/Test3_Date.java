package cn.tedu.api;
import java.util.Date;
//测试 Date工具类
public class Test3_Date {
    public static void main(String[] args) {
        //1,创建对象
        Date d = new Date();
        //2,调用方法
        //从1970.1.1 0点到现在的毫秒值
        System.out.println( d.getTime() );
        System.out.println( d.getDate() );//今天是多少号
        System.out.println( d.getDay() );//今天礼拜几
        System.out.println( d.getHours() );//现在是几点
        System.out.println( d.getMinutes() );//现在是哪一分钟
        System.out.println( d.getMonth() );//获取月份,自然月-1
        System.out.println( d.getSeconds() );//现在是几几秒
        System.out.println( d.getClass());//获取类的对象
        System.out.println( d.toLocaleString() );
        //2020-12-15 14:52:48
        //获取年份,从1900到现在是多少年,120
        System.out.println( d.getYear() );
    }
}
