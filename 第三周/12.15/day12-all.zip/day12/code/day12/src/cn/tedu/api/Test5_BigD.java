package cn.tedu.api;

import java.math.BigDecimal;
import java.util.Scanner;

//测试
public class Test5_BigD {
    public static void main(String[] args) {
//        method();//+-*/
        method2();//用工具
    }
    //用工具
    private static void method2() {
        double a =  new Scanner(System.in).nextDouble();
        double b =  new Scanner(System.in).nextDouble();
        //1,创建对象

        //构造方法,double类型的不能用,更不精确!!!!
//        BigDecimal bd1 = new BigDecimal(a);
//        BigDecimal bd2 = new BigDecimal(b);

        //用String类型的构造方法!!!!
        //double->String
        //方式1:String.valueOf(a)
        //方式2: a+""
 BigDecimal bd1 = new BigDecimal(a+"" );
        BigDecimal bd2 = new BigDecimal(b+"" );
        //2,调用方法
        BigDecimal bd3 = bd1.add(bd2);//加法
        System.out.println(bd3);

        bd3 = bd1.subtract(bd2);//减法
        System.out.println(bd3);

        bd3 = bd1.multiply(bd2);//乘法
        System.out.println(bd3);

 //除不尽的异常:java.lang.ArithmeticException
//        bd3 = bd1.divide(bd2);//除法
  //divide(1,2,3)--1就是想除谁 2就是要保留几位 3舍入方式
        bd3 = bd1.divide(bd2,3,BigDecimal.ROUND_HALF_UP);//除法
        System.out.println(bd3);
    }
    //+-*/
    public static void method() {
        //接收用户输入的两个小数
        double a =  new Scanner(System.in).nextDouble();
        double b =  new Scanner(System.in).nextDouble();
        //运算
        System.out.println(a+b);//不精确
        System.out.println(a-b);//不精确
        System.out.println(a*b);//不精确
        System.out.println(a/b);//不精确
    }
}
