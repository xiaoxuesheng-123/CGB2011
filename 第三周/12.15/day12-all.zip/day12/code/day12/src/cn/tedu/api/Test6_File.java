package cn.tedu.api;
import java.io.File;
//测试 File文件流
public class Test6_File {
    public static void main(String[] args) {
        //1,创建对象 -- 指定文件的路径
        File file =
                new File("D:\\iotest\\1.txt");
        //2,调用方法
        System.out.println(file.getName());
        System.out.println(file.length());
        //TODO
//        length()：文件的字节量
//        exists()：是否存在，存在返回true
//        isFile()：是否为文件，是文件返回true
//        isDirectory()：是否为文件夹，是文件夹返回true
//        getName()：获取文件/文件夹名
//        getParent()：获取父文件夹的路径
//        getAbsolutePath()：获取文件的完整路径
//        createNewFile()：新建文件，文件夹不存在会异常，文件已经存在返回false
//        mkdirs()：新建多层不存在的文件夹\a\b\c
//        mkdir()：新建单层不存在的文件夹\a
//        delete()：删除文件，删除空文件夹
//        list()：返回String[]，包含文件名
//        listFiles()：返回File[]，包含文件对象
    }
}
