package cn.tedu.api;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

//测试 日期格式化工具类
public class Test4_Date2 {
    public static void main(String[] args)
                        throws ParseException {
//        method();//互转
        method2();//出生天数
    }
    //出生天数
    public static void method2()
                    throws ParseException {
        //1,接收一串 输入的 出生日期
String birthday = new Scanner(System.in).nextLine();
        //2,使用工具类
SimpleDateFormat sdf =
        new SimpleDateFormat("yyyy-MM-dd");
       //把String->Date
        Date day = sdf.parse(birthday);
        //算天数
        long start = day.getTime();//出生的毫秒值
        long now = System.currentTimeMillis();//现在的毫秒值
        // ms->天
        System.out.println((now-start)/1000/60/60/24 );
    }
    //互转
    public static void method()
                        throws ParseException {
        //1,创建对象--指定日期的格式
   SimpleDateFormat s =
                //y表示年 M表示月 d表示日
       new SimpleDateFormat("yyyy-MM-dd");

   //2,调用方法 String -> Date
        Date d = s.parse("1990-1-1");
        //好处是:使用Date的getXxx()
        System.out.println(d.getMonth()+1);
    }
}
