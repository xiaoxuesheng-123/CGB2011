package cn.tedu.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

//测试 HashMap
public class Test1_HashMap {
    public static void main(String[] args) {
       //1,创建对象
       HashMap<Integer,String> map = new HashMap();
       //2,调用方法
       map.put(1,"蔡徐坤");
       map.put(2,"王一博");
       map.put(2,"刘德华");
       map.put(3,"肖战");
       map.put(4,"靳东");
       map.put(5,"易烊千玺");
       System.out.println(map);
       //迭代map集合
       for(Integer key : map.keySet()){
           String value = map.get(key);
           System.out.println(key+value);
       }
       for (String value : map.values()) {
           System.out.println(value);
       }
//       map.entrySet();
       //把key和value封装成Entry对象存入set
        for(Map.Entry<Integer, String> entry : map.entrySet() ) {
            Integer key = entry.getKey();
            String value = entry.getValue();
            System.out.println(key+value);
        }
    }
}
