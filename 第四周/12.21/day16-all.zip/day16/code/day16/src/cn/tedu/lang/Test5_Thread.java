package cn.tedu.lang;
//测试 模拟多线程编程
public class Test5_Thread {
    public static void main(String[] args) {
        //3,使用线程类
        MyRunnable target = new MyRunnable();
        //绑定关系
        Thread t = new Thread(target);
        t.start();//启动线程

        Thread t2 = new Thread(target);
        t2.start();//启动线程
        /*多线程的随机性
            Thread-1~~3
            Thread-1~~4
            Thread-0~~0
            Thread-1~~5
            Thread-0~~1
         */
    }
}
//1,定义线程类--实现Runnable接口
class MyRunnable implements Runnable{
    //2,把业务 放在重写的run()
    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            //获取线程名称:Thread.currentThread().getName()
            System.out.println(Thread.currentThread().getName()+"~~"+i);
        }
    }
}
