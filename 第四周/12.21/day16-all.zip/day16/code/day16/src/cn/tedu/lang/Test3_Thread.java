package cn.tedu.lang;
//测试 Thread
public class Test3_Thread {
    public static void main(String[] args)
            throws InterruptedException {
        //1,创建对象
        Thread t = new Thread();
        //2,调用方法
        System.out.println( t.getId() );//获取线程id
        System.out.println( t.getName() );//获取线程名称Thread-0
        t.run();
        t.setName("tony");//设置线程的名称
        System.out.println( t.getName() );
        t.start();//开启线程
        t.stop();//结束线程
        //让线程休眠10ms
        Thread.sleep(10);
//        获取正在执行任务的线程对象的引用
        Thread t2 = Thread.currentThread();
        System.out.println(t2.getName());//main

        System.out.println(Thread.currentThread().getId());

    }
}
