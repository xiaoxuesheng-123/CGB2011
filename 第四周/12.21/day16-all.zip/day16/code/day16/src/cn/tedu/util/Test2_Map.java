package cn.tedu.util;

import java.util.HashMap;
import java.util.Scanner;

//map的练习
public class Test2_Map {
    public static void main(String[] args) {
        //统计字符串中的字符个数
        System.out.println("请输入字符串:");
        String input = new Scanner(System.in).nextLine();
        //定义map存数据 {a=null,b=3,c=5}
        HashMap<Character,Integer> map = new HashMap();
        //遍历字符串,得到每个字符
        for (int i = 0; i < input.length(); i++) {
            //根据下标,获取字符
            char key = input.charAt(i);
            Integer value = map.get(key);
            if(value==null){//如果是null就是没存过,直接存1
                map.put(key,1);
            }else{//如果不是null,就+1
                map.put(key,value+1);
            }
        }
        //abac   {a=2, b=1, c=1}
        System.out.println(map);
    }
}
