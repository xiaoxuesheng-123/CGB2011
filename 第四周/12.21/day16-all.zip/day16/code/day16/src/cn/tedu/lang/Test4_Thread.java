package cn.tedu.lang;
//模拟多线程编程
public class Test4_Thread {
    public static void main(String[] args) {
        //3,使用线程类
        MyThread t = new MyThread();//新建状态
//        t.run();//普通的方法调用,没有抢的多线程效果
        t.start();//可运行状态,等着CPU选中
        t.setName("1号线程");//设置线程名称
        //TODO 模拟多线程
        MyThread t2 = new MyThread();
        //4,启动线程 + 找到线程里的run()执行
        t2.start();
        t2.setName("2号线程");
        /*
        多线程的随机性:全是CPU调度的,程序无法控制
            Thread-0===0
            Thread-1===0
            Thread-1===1
            Thread-0===1
            Thread-0===2
         */
    }
}
//1,定义线程类--继承Thread类
class MyThread extends Thread{
    //2,自己的业务--必须放在重写的run()里
    @Override
    public void run() {//运行状态
        for (int i = 0; i < 10; i++) {
            //打印10次线程名称
            System.out.println(super.getName()+"==="+i);
        }
    }//终止状态
}