package cn.tedu.reflect;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;

//反射Student类里的数据
public class Test3_Student {
    public static void main(String[] args) throws Exception {
        //1,获取Class对象
        Class c1 = Student.class;
//        method(c1);//反射方法们
//        method2(c1);//反射成员变量们
//        method3(c1);//反射构造方法们
//        method4(c1);//利用反射创建对象
        method5(c1);//利用反射给成员变量set/get
//        method6(c1);//利用反射运行方法
    }
    //利用反射运行方法
    private static void method6(Class c1) throws Exception {
 //获取一个方法 public void show(int a)
 //getMethod(1,2)-1是方法名,2是参数类型的class对象
        Method m = c1.getDeclaredMethod("show",int.class);
        //让反射执行方法
        Object oo = c1.newInstance();

  //问题是:show方法被私有了,要进行写/改的操作,必须开启权限
        m.setAccessible(true);//默认是没权限的
        //invoke(1,2)-1是对象,2是方法具体要传入的参数
        m.invoke(oo,10000);
    }
    //利用反射给成员变量set/get
    private static void method5(Class c1) throws Exception {
        //获取一个成员变量
        Field f = c1.getDeclaredField("age");
        //set(1,2)--1是对象,2给属性赋的具体值
        Object o = c1.newInstance();

        //对私有的属性,修改,必须有权限!!
        f.setAccessible(true);//开启权限
        f.set(o,1000);//设置属性的值

        Object x = f.get(o);//设置属性的值
        System.out.println(x);//1000?
    }
    //利用反射创建对象
    private static void method4(Class c1) throws Exception {
        //利用反射 触发 无参构造 创建对象
        Object s = c1.newInstance();
        System.out.println(s);
        //利用反射 触发 含参构造 创建对象
        //public Student(String name)
        //getConstructor的参数 是String类型的Class对象
        Constructor c = c1.getConstructor(String.class);
        //newInstance的参数 是给构造方法传入的具体的参数
        Object o = c.newInstance("jack");
        System.out.println(o);
    }
    //反射构造方法们
    private static void method3(Class c1) {
        //获取所有的 公开的 构造方法们
        Constructor[] cs = c1.getConstructors();
        //遍历数组,获取每个构造方法c
        for (Constructor c : cs) {
            //获取构造方法的名字
            System.out.println(c.getName());
            //获取参数的类型
            Class[] cs2 = c.getParameterTypes();
            System.out.println(Arrays.toString(cs2));
        }
    }
    //反射成员变量们
    private static void method2(Class c1) {
        //获取所有的 公共的 成员变量们
//        Field[] fs = c1.getFields();
        //获取所有属性,,公开的 私有的默认的
        Field[] fs = c1.getDeclaredFields();
        //遍历数组,获取每个成员变量f
        for(Field f:fs){
            //获取变量名
            System.out.println(f.getName());
            //获取变量类型
            System.out.println(f.getType().getName());
        }
    }
    //反射方法们
    private static void method(Class c) {
        //获取所有的 公共的 方法们--有自己的和Object的
//        Method[] ms = c.getMethods();

        //获取 公开的 私有的 默认的
        Method[] ms = c.getDeclaredMethods();
        //遍历数组,得到每个方法m
        for(Method m : ms){
            //获取方法名getName()
            String name = m.getName();
            System.out.println(name);
            //获取方法的 参数的类型
            Class[] cs = m.getParameterTypes();
            System.out.println( Arrays.toString(cs) );
        }
    }
}
