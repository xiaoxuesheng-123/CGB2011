package cn.tedu.reflect;
//测试 反射
public class Test2 {
    public static void main(String[] args)
                throws ClassNotFoundException {
        method();//获取Class对象
    }
    //获取Class对象 -- 解析String.class
    private static void method()
                throws ClassNotFoundException {
        //三种方式:
//        类名.class
//        对象.getClass()
//        Class.forName("全路径名")--包名.类名
        Class c1 = String.class;
        Class c2 = new String().getClass();
        Class c3 = Class.forName("java.lang.String");
        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
        //TODO 解析String.class 里的所有方法
    }

}
