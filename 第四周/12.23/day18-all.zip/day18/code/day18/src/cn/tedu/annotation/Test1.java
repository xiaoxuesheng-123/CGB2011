package cn.tedu.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

//测试 自定义注解 ::
//Constructor构造方法
//Field属性/变量
//Method方法
//Type类/类型
//Annotation注解
public class Test1 {
    public static void main(String[] args) {

    }
}
//第一步:自定义一个注解--jdk/框架提供的
//语法:@interface 注解名
//元注解,用来描述注解的生命周期
@Retention(RetentionPolicy.SOURCE)
//元注解,用来描述注解的出现的位置--出现在类上
//@Target(ElementType.TYPE)
@Target({ElementType.TYPE , ElementType.FIELD})
@interface Test{
//    String name() ;//加属性,谁用
    String name() default "jack";//给属性加默认值
    int age() default 10;
    String value();//特殊的属性--特殊在用时直接赋值
}
//第二步:使用注解--必会
//语法:@注解名
@Test("abc")//简写value="abc"
//@Test(name="tony",age=20)//都改掉
//@Test(age=18)//给age属性赋值
//@Test(name="Hello")//给name属性赋值
class Hello{
}


