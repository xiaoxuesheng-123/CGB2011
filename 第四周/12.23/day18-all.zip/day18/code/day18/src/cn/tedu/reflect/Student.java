package cn.tedu.reflect;
//测试 反射
public class Student {
    //TODO Constructors
    public Student() { }
    public Student(String name) {
        this.name = name;
    }
    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }
    //TODO Fields --加public方便反射
    String name;
    private int age;
    //TODO Methods
    private void show(int a){
        System.out.println("show()-"+a);
    }
}
