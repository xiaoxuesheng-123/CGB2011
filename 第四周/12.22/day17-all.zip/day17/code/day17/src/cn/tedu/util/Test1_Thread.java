package cn.tedu.util;
//模拟多线程售票 --继承Thread类
public class Test1_Thread {
    public static void main(String[] args) {
        //创建4个线程,模拟4个窗口
        MyTickets t1 = new MyTickets();
        MyTickets t2 = new MyTickets();
        MyTickets t3 = new MyTickets();
        MyTickets t4 = new MyTickets();
        //启动线程
        t1.start();
        t2.start();
        t3.start();
        t4.start();
    }
}
class MyTickets extends Thread{
//TODO 如果共享资源是静态的,锁对象必须固定--类名.class
    static int tickets = 100;
    @Override
//TODO 2,同步方法,会自动分配锁对象,不需要你考虑
//普通方法默认分配this,静态方法默认分配类名.class
// synchronized public void run() {//没锁住
    public void run() {
        while(true){
//TODO 1,同步代码块:
// synchronized (this){因为共享资源是静态的this锁不住
            synchronized (MyTickets.class){
                if(tickets > 0){
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println(super.getName()+"~~"+tickets--);
                }else{
                    break;//是死循环的出口!!
                }

            }
        }
    }
}





