package cn.tedu.util;
//测试 单例设计模式
public class Test3_Singleton {
    public static void main(String[] args) {
        //TODO 现在是多例
//        new Student();
//        new Student();
//        new Student();
        //TODO 实现单例
        Student s = Student.get();
        Student s2 = Student.get();
        //是同一个对象吗?--地址值相同就是同一个对象
//eqals():如果使用Object的就是比地址值,如果重写了比属性值
        //== :比基本类型的数值本身,比引用类型的地址值
        System.out.println( s == s2);//true

        Student2 s3 = Student2.get();
        Student2 s4 = Student2.get();
        System.out.println( s3 == s4);
    }
}
//懒汉式--面试常见--按需加载/延迟加载--线程安全
class Student2{
    private Student2(){}
    static private Student2 s;//没有第一时间new
    //TODO 共享资源s被多条语句操作了,一定会不安全,需要加锁
    synchronized static public Student2 get(){
//        synchronized (Student2.class){
            //没new过才new呢,new过了就算了
            if(s == null){
                s = new Student2();//需要时才new
            }
            return s;//把new好的返回
//        }
    }
}
//饿汉式--自己用
//TODO 多线程编程中,有数据安全隐患吗 ?
// 当共享资源 被多条语句操作时,一定会有问题,选择加锁!!
class Student{
    //1,私有化构造方法,不让外界随便new
    private Student(){}
    //2,自己 给外界new一个
//加static:被静态资源get()调用的资源s,也必须得是静态的
    static private Student s = new Student();
    //TODO 3,提供方法,并返回s方便外界调用
//加static:不能用对象调用这个方法了,只能变成静态的,通过类名调用
    static public Student get(){
        return s;
    }
}