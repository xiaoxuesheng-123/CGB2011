package cn.tedu.util;
//模拟多线程售票 --实现Runnable接口
public class Test2_Thread {
    public static void main(String[] args) {
        MyTickets2 target = new MyTickets2();
        Thread t1 = new Thread(target);
        Thread t2 = new Thread(target);
        Thread t3 = new Thread(target);
        Thread t4 = new Thread(target);
        t1.start();
        t2.start();
        t3.start();
        t4.start();
    }
}
class MyTickets2 implements Runnable{
    int tickets = 100;//定义变量,记录票数
    Object o = new Object();
//TODO 1,给方法加锁,让多线程 排队等待的效果,实现了数据的安全但是牺牲了效率
//synchronized public void run() {
    @Override
    public void run() {
//TODO 2,给代码块加锁,要考虑两个问题:锁的位置+锁对象是啥
//同步代码块的锁对象 可以任意,但是必须是同一个对象!!!
        while(true){
//            synchronized (new Object()){//不是同一个对象
//            synchronized (o){//只有一个对象
//            synchronized ("123"){//只有一个对象
            synchronized (this){
                if(tickets>0){
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println(Thread.currentThread().getName()+"==="+tickets--);
                }else{
                    break;
                }
            }
        }
    }
}